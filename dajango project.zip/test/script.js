let cart = [];

function addToCart(item, price) {
    cart.push({item, price});
    alert(item + ' added to cart');
}

function orderOnline() {
    if (cart.length === 0) {
        alert('Your cart is empty');
        return;
    }
    let orderSummary = 'Your Order:\n';
    let total = 0;
    cart.forEach(cartItem => {
        orderSummary += `${cartItem.item} - €${cartItem.price}\n`;
        total += cartItem.price;
    });
    orderSummary += `Total: €${total}`;
    alert(orderSummary);
}

function submitForm(event) {
    event.preventDefault();
    alert('Thank you for contacting us!');
    document.getElementById('contactForm').reset();
}
